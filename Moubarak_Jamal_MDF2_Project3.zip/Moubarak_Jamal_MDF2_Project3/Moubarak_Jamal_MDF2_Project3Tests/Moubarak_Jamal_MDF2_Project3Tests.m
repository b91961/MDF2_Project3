//
//  Moubarak_Jamal_MDF2_Project3Tests.m
//  Moubarak_Jamal_MDF2_Project3Tests
//
//  Created by Jamal Moubarak on 3/18/14.
//  Copyright (c) 2014 Jamal Moubarak. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface Moubarak_Jamal_MDF2_Project3Tests : XCTestCase

@end

@implementation Moubarak_Jamal_MDF2_Project3Tests

- (void)setUp
{
    [super setUp];
    // Put setup code here. This method is called before the invocation of each test method in the class.
}

- (void)tearDown
{
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    [super tearDown];
}

- (void)testExample
{
    XCTFail(@"No implementation for \"%s\"", __PRETTY_FUNCTION__);
}

@end
